import plotly as py
import plotly.plotly as plty
import plotly.graph_objs as go
import ipywidgets as widgets
import numpy as np
from scipy import special

py.offline.init_notebook_mode(connected=True)

x = np.linspace(-3*np.pi,3*np.pi,1000)

layout = go.Layout(
    title='Sinusoidal function',
    yaxis=dict(
        title='sin(x)'
    ),
    xaxis=dict(
        title='x'
    )
)

trace1 = go.Scatter(
    x=x,
    y=np.sin(x),
    mode='lines+markers',
    name='sin(x)',
    line=dict(
        shape='spline'
    )
)
fig = go.Figure(data=[trace1],layout=layout)
#fig = {'data':[trace1],'layout':layout}
#py.offline.plot(fig,image = 'png',filename='.\images\plot_image', image_width=800, image_height=600, validate=False)
plty.image.save_as(fig,'my_image.png')
# py.io.orca.config.executable = 'C:/Users/rku172/AppData/Local/Programs/orca/orca.exe'
# py.io.write_image(fig,'images/chart.png')